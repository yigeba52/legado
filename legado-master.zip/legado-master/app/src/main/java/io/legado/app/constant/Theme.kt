package io.legado.app.constant

enum class Theme {
    Dark, Light, Auto, Transparent, EInk;
}