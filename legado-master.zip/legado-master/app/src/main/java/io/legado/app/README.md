# 文件结构介绍

* api 提供的接口
* base 基类
* constant 常量
* data 数据
* exception 错误类型
* help 帮助
* lib 库
* model 解析
* receiver 广播侦听
* service 服务
* ui 界面
* utils 辅助类
* web web服务