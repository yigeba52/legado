# 放置一些模块类

* analyzeRule 书源规则解析
* localBook 本地书籍解析
* rss 订阅规则解析
* webBook 获取网络书籍

