package io.legado.app.exception

class RegexTimeoutException(msg: String) : NoStackTraceException(msg)