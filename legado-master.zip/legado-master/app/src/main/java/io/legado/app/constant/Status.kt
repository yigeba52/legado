package io.legado.app.constant

object Status {
    const val STOP = 0
    const val PLAY = 1
    const val PAUSE = 3
}