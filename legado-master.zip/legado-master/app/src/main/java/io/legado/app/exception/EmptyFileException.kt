package io.legado.app.exception

/**
 * 文件为空
 */
class EmptyFileException(msg: String) : NoStackTraceException(msg)