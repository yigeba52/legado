* 由于安卓的存储访问限制，阅读需要设置**公共目录下的子目录**来实现书籍拷贝、下载，例如Documents/Books、Download/Books
* 如不设置，将无法正常使用本地书籍、webDav书籍的相关功能